import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddUserComponent } from './components/add-user/add-user.component';
import { EditUpdateComponent } from './components/edit-update/edit-update.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { ModifyUserListComponent } from './components/modify-user-list/modify-user-list.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { ShowAddedUserComponent } from './components/show-added-user/show-added-user.component';
import { ShowUserInfoComponent } from './components/show-user-info/show-user-info.component';

const routes: Routes = [
  {path : '', redirectTo : '/contacts/admin' , pathMatch : 'full'},
  {path : 'contacts/admin', component : HomepageComponent},
  {path : 'contacts/add', component : AddUserComponent },
  {path : 'contacts/showadded', component : ShowAddedUserComponent },
  {path : 'contacts/modify', component : ModifyUserListComponent},
  {path : 'contacts/showinfo', component : ShowUserInfoComponent },
  {path : 'contacts/edit', component : EditUpdateComponent},
  {path : '**', component : PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
