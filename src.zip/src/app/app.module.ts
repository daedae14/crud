import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './components/homepage/homepage.component';
import { AddUserComponent } from './components/add-user/add-user.component';
import { ShowAddedUserComponent } from './components/show-added-user/show-added-user.component';
import { ModifyUserListComponent } from './components/modify-user-list/modify-user-list.component';
import { ShowUserInfoComponent } from './components/show-user-info/show-user-info.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { EditUpdateComponent } from './components/edit-update/edit-update.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    AddUserComponent,
    ShowAddedUserComponent,
    ModifyUserListComponent,
    ShowUserInfoComponent,
    PageNotFoundComponent,
    NavbarComponent,
    EditUpdateComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
