import { Component, OnInit, Input} from '@angular/core';
import { RestApiService } from 'src/app/services/shared/rest-api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']

})

export class AddUserComponent implements OnInit {


  @Input() userDetails = { id: '', name: '', email: '', phone:'' };
  constructor(public restApi: RestApiService, public router: Router) {}
  ngOnInit() {}
  addUser(dataUser: any) {
    this.restApi.createUsers(this.userDetails).subscribe((data: {}) => {
      this.router.navigate(['/contacts/modify']);


    });
  }
}
