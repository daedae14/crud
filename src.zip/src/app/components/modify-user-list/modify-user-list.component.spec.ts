import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyUserListComponent } from './modify-user-list.component';

describe('ModifyUserListComponent', () => {
  let component: ModifyUserListComponent;
  let fixture: ComponentFixture<ModifyUserListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModifyUserListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ModifyUserListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
