import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAddedUserComponent } from './show-added-user.component';

describe('ShowAddedUserComponent', () => {
  let component: ShowAddedUserComponent;
  let fixture: ComponentFixture<ShowAddedUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAddedUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAddedUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
