import { Component, OnInit } from '@angular/core';
import { RestApiService } from 'src/app/services/shared/rest-api.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit-update',
  templateUrl: './edit-update.component.html',
  styleUrls: ['./edit-update.component.css']
})
export class EditUpdateComponent implements OnInit {

    id = this.actRoute.snapshot.params['id'];
    userData : any = {};
  constructor(
    public restApi: RestApiService,
    public actRoute: ActivatedRoute,
    public router: Router
  ) { }

  ngOnInit() {
    this.restApi.getUser(this.id).subscribe((data: {}) => {
      this.userData = data;
  })
}

updateUser() {
  if(window.confirm('Are you sure, you want to update?')){
    this.restApi.updateUsers(this.id, this.userData).subscribe(data => {
      this.router.navigate(['/contacts/edit'])
    })
  }
}
}
