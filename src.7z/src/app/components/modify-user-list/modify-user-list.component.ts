import { Component, OnInit } from '@angular/core';
import { RestApiService } from 'src/app/services/shared/rest-api.service';

@Component({
  selector: 'app-modify-user-list',
  templateUrl: './modify-user-list.component.html',
  styleUrls: ['./modify-user-list.component.css']
})
export class ModifyUserListComponent implements OnInit {

  User : any = [];


  constructor(public restApi: RestApiService) { }
   ngOnInit() {
    this.loadUser();
  }

  loadUser() {
    return this.restApi.getUsers().subscribe((data: {}) => {
      this.User = data;
    });
  }
  deleteUser(id: any) {
    if (window.confirm('Are you sure, you want to delete?')) {
      this.restApi.deleteUsers(id).subscribe((data) => {
        this.loadUser();
      });
    }
  }
}
