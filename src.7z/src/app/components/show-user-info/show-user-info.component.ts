import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-user-info',
  templateUrl: './show-user-info.component.html',
  styleUrls: ['./show-user-info.component.css']
})
export class ShowUserInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
